create function trig_user_recipe_ai_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE counts
    SET recipes = recipes + 1
    WHERE id = NEW.user_id;
END;
$$;

alter function trig_user_recipe_ai_func() owner to postgres;

