create function trig_users_ai_func() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO counts (user_id)
    VALUES (NEW.id);

    INSERT INTO user_category (user_id, category_id)
    SELECT NEW.id, id
    FROM categories
    WHERE name IN (
                   'uncategorized', 'appetizers', 'bread', 'breakfasts', 'condiments',
                   'dessert', 'lunch', 'main dish', 'salad', 'side dish',
                   'snacks', 'soups', 'stews'
        );
END;
$$;

alter function trig_users_ai_func() owner to postgres;

