create function trig_cookbooks_ai_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE counts
    SET cookbooks = cookbooks + 1
    WHERE user_id = NEW.user_id;
END;
$$;

alter function trig_cookbooks_ai_func() owner to postgres;

