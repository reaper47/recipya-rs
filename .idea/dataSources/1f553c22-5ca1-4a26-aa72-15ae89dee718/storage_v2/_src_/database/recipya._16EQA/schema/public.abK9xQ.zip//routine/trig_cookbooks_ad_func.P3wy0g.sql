create function trig_cookbooks_ad_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE counts
    SET cookbooks = cookbooks - 1
    WHERE user_id = OLD.user_id;

    --     DELETE
--     FROM cookbooks_fts
--     WHERE id = OLD.id
--       AND user_id = OLD.user_id;

    RETURN NULL;
END;
$$;

alter function trig_cookbooks_ad_func() owner to postgres;

