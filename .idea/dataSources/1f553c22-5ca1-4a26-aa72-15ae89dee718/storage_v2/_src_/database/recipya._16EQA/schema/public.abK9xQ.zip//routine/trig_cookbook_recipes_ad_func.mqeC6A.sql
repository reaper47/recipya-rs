create function trig_cookbook_recipes_ad_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE cookbooks
    SET count = count - 1
    WHERE OLD.cookbook_id = id;

    RETURN NULL;
END;
$$;

alter function trig_cookbook_recipes_ad_func() owner to postgres;

