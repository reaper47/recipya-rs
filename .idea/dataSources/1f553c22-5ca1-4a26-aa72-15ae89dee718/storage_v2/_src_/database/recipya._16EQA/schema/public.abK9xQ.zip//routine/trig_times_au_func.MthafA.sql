create function trig_times_au_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE times
    SET total_seconds = NEW.prep_seconds + NEW.cook_seconds
    WHERE id = NEW.id;

    RETURN NULL;
END;
$$;

alter function trig_times_au_func() owner to postgres;

