create function trig_user_recipe_ad_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE counts
    SET recipes = recipes - 1
    WHERE id = OLD.user_id;

    RETURN NULL;
END;
$$;

alter function trig_user_recipe_ad_func() owner to postgres;

