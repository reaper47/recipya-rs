create function trig_cookbook_recipes_ai_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE cookbooks
    SET count = count + 1
    WHERE NEW.cookbook_id = id;

    RETURN NULL;
END;
$$;

alter function trig_cookbook_recipes_ai_func() owner to postgres;

