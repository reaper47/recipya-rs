create function trig_recipes_au_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE recipes
    SET updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;
$$;

alter function trig_recipes_au_func() owner to postgres;

