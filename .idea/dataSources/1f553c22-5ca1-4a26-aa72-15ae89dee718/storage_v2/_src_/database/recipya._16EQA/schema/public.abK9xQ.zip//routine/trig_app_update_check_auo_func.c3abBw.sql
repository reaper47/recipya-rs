create function trig_app_update_check_auo_func() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE app
    SET update_last_checked_at = CURRENT_TIMESTAMP
    WHERE id = 1;

    RETURN NULL;
END;
$$;

alter function trig_app_update_check_auo_func() owner to postgres;

